#include<stdio.h>
int main()
{
    int A, B, result;

    scanf("%d %d", &A, &B);
    result=A%B;
    printf("%d\n", result);

    return 0;
}
