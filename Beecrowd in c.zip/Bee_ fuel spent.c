#include <stdio.h>
int main()
{
    float a, b, n;

    scanf("%f %f", &a, &b);
    n=(a*b)/12;
    printf("%.3f\n", n);

    return 0;
}
