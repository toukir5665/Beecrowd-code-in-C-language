#inlcude<stdio.h>
int main()
{
    int  n, hun, fif, tt, tn, two, one;
    scanf("")



    return 0;
}
