#include<stdio.h>
int main()
{
    double R, result;
    scanf("%lf", &R);
    result=3.14159*(R*R);
    printf("A=%.4f\n", result);

    return 0;
}
