#include<stdio.h>
int main()
{
    int n, t;

    scanf("%d", &n);
    t=n*2;
    printf("%d minutos\n", t);

    return 0;
}
